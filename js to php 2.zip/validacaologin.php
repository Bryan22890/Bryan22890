<?php
echo '<script>
document.querySelector("form").addEventListener("submit", function(event) {
    event.preventDefault();
});

function validarlogin() { //Essa função Verifca se os campos estão preenchidos ou não
    var usuario = document.getElementById("usuario").value; //".value" serve para armazenar os valores que vão ser inseridos no campo
    var senha = document.getElementById("senha").value;
    
    if (usuario === "" || senha === "") {
        alert("[ERRO] Usuário ou senha não preenchidos.")
        return false;
    }
    return true; //Retorna True se os campos estão preenchidos
}
</script>';
?> 

<?php
// Essa função pega os dados do input login e senha da tela de login
function recuperarDados() {
    // Obtém os valores do formulário POST
    $campousuario = $_POST['usuario'] ?? '';
    $camposenha = $_POST['senha'] ?? '';

    // Inicia a sessão para acessar os dados armazenados
    session_start();
    
    // Obtém os usuários da sessão ou um array vazio se não existir
    $usuarios = $_SESSION['usuarios'] ?? [];

    // Procurando o usuário que corresponde ao login e à senha
    $usuarioEncontrado = null;
    foreach ($usuarios as $usuario) {
        if ($usuario['login'] === $campousuario && $usuario['senha'] === $camposenha) {
            $usuarioEncontrado = $usuario;
            break;
        }
    }

    return $usuarioEncontrado;
}
?> 

<?php
// Função para validar login (presumivelmente definida em outro lugar)
function validarlogin() {
    // Implementação da validação de login 
    // Retorna true se os dados forem válidos, false caso contrário
}

// Função para recuperar dados (presumivelmente definida em outro lugar)
function recuperarDados() {
    // Lógica para recuperar dados de usuário
}

// Função de login
function login() {
    // Verifica a validação antes de continuar
    if (!validarlogin()) {
        return;
    }
    
    recuperarDados();
    
    // Verifica se o usuário foi encontrado
    global $usuarioEncontrado; // Assumindo que $usuarioEncontrado é definido globalmente
    
    if ($usuarioEncontrado) {
        // Em PHP, usamos sessões em vez de localStorage
        session_start();
        $_SESSION['usuarioLogado'] = json_encode($usuarioEncontrado);
        
        // Em PHP, usamos mensagens de sessão ou alerts via JavaScript
        $_SESSION['mensagem'] = 'Login bem-sucedido!';
        
        // Redireciona para a página desejada
        header('Location: ../html/telasobrenos.html');
        exit(); // Importante para parar a execução após o redirecionamento
    } else {
        // Armazena mensagem de erro na sessão
        $_SESSION['erro'] = '[ERRO] Usuário ou senha incorreto(a).';
        
        // Pode redirecionar de volta para a página de login
        header('Location: login.php');
        exit();
    }
}
?>
