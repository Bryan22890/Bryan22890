<?php
function toggleNews($element) {
    $isExpanded = in_array('expanded', $element->classList);
    
    // Remove a expansão de todas as notícias
    foreach (document.querySelectorAll('.news-item') as $item) {
        $item->classList->remove('expanded');
    }
    
    // Se não estava expandido, expande
    if (!$isExpanded) {
        $element->classList->add('expanded');
    }
}
?>
