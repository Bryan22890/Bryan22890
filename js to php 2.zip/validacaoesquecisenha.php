<?php
// Evento de prévenção de comportamento padrão do formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Chama a função para recuperar a senha
    recuperarSenha();
}

// Essa função pega os dados do input login e senha da tela de login;
function recuperarSenha() {
    $esquecisenha = $_POST['esquecisenha'];
    $usuarios = json_decode(file_get_contents('usuarios.json'), true) ?: [];
}
?>

    
<?php
// Verifica se o campo de e-mail está vazio
if ($esquecisenha === '') {
    echo '[ERRO] Por favor, insira seu e-mail.';
    return;
}

/* Procurando o usuário que corresponde ao login e à senha. Para isso, criei uma variável,
daí coloquei o nome da variável que eu coloquei acima e 'array_filter' para encontrar o objeto e as propriedades usuario e senha */
$emailEncontrado = array_filter($usuarios, function($usuario) use ($esquecisenha) {
    return $usuario['email'] === $esquecisenha;
});
$emailEncontrado = reset($emailEncontrado); // Para obter o primeiro elemento encontrado
?>


<?php
/* Aqui é um if básico, se os dados da variável acima forem encontrados, aparece o alerta de login bem sucedido
    e direciona para a tela sobre nós, caso não vai alertar que o usuário e a senha estão incorretos */
if ($emailEncontrado) {
    $_SESSION['emailLogado'] = json_encode($emailEncontrado);
    echo "<script>alert('Um link de instruções foi encaminhado para o seu e-mail. Não esqueça de verificar sua caixa de spam.');</script>";
    echo "<script>document.getElementById('email_esquecisenha').value = '';</script>";
    echo "<script>document.getElementById('confirmaemail_esquecisenha').value = '';</script>";
} else {
    echo "<script>alert('[ERRO] E-mail não encontrado. Por favor, verifique os dados inseridos');</script>";
    return false;
}

echo "<script>
document.getElementById('enviar').addEventListener('click', function(event) {
    event.preventDefault();
    recuperarSenha();
});
</script>";
?>
