import React, { useContext } from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import LoginScreen from './screens/LoginScreen';
import CadastroScreen from './screens/CadastroScreen';
import ListaUsuariosScreen from './screens/ListaUsuariosScreen';
import { UserContext } from './UserContext';

export type RootStackParamList = {
  Login: undefined;
  Cadastro: undefined;
  ListaUsuarios: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

export default function StackNavigator() {
  const { loggedIn } = useContext(UserContext);

  return (
    <Stack.Navigator>
      {!loggedIn ? (
        <>
          <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
          <Stack.Screen name="Cadastro" component={CadastroScreen} options={{ title: 'Cadastro' }} />
        </>
      ) : (
        <Stack.Screen
          name="ListaUsuarios"
          component={ListaUsuariosScreen}
          options={{ title: 'Usuários Cadastrados' }}
        />
      )}
    </Stack.Navigator>
  );
}
