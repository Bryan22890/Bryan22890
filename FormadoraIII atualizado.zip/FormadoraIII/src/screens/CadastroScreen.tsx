import React, { useContext, useState } from 'react';
import { View, Text, StyleSheet, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import CustomInput from '../components/CustomInput';
import CustomButton from '../components/CustomButton';
import { UserContext } from '../UserContext';


export default function CadastroScreen({ navigation }: any) {
const [nome, setNome] = useState('');
const [email, setEmail] = useState('');
const [senha, setSenha] = useState('');


const { users, addUser } = useContext(UserContext);


const handleCadastrar = () => {
if (!nome || !email || !senha) return Alert.alert('Erro', 'Preencha todos os campos.');


const exists = users.some((u) => u.email === email.trim().toLowerCase());
if (exists) return Alert.alert('Erro', 'Email já em uso.');


const novo = { id: Date.now().toString(), nome: nome.trim(), email: email.trim().toLowerCase(), senha };
addUser(novo);
Alert.alert('Sucesso', 'Cadastro realizado com sucesso.');
navigation.goBack();
};


return (
<KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.container}>
<View style={styles.card}>
<Text style={styles.title}>Crie sua Conta</Text>


<CustomInput placeholder="Nome" value={nome} onChangeText={setNome} />
<CustomInput placeholder="Email" value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" />
<CustomInput placeholder="Senha" value={senha} onChangeText={setSenha} secureTextEntry />


<CustomButton title="Cadastrar" onPress={handleCadastrar} />
</View>
</KeyboardAvoidingView>
);
}


const styles = StyleSheet.create({
container: { flex: 1, justifyContent: 'center', backgroundColor: '#f2f4f8' },
card: { margin: 20, padding: 20, backgroundColor: '#fff', borderRadius: 12, elevation: 3 },
title: { fontSize: 22, fontWeight: '700', marginBottom: 12, textAlign: 'center' }
});