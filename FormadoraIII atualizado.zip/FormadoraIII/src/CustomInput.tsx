import React from 'react';
import { View, TextInput, StyleSheet, TextInputProps } from 'react-native';


type Props = TextInputProps & { containerStyle?: object };


export default function CustomInput(props: Props) {
return (
<View style={[styles.container, props.containerStyle]}>
<TextInput
{...props}
placeholderTextColor="#8a8f98"
style={styles.input}
/>
</View>
);
}


const styles = StyleSheet.create({
container: { width: '100%', marginVertical: 8 },
input: {
padding: 12,
borderRadius: 10,
borderWidth: 1,
borderColor: '#e6e6e6',
backgroundColor: '#fff'
}
});