import React from 'react';
import { NavigationContainer, DefaultTheme, DarkTheme } from '@react-navigation/native';
import { useColorScheme } from 'react-native';
import StackNavigator from './src/StackNavigator';
import { UserProvider } from './src/UserContext';

export default function App() {
  const colorScheme = useColorScheme();

  return (
    <UserProvider>
      <NavigationContainer theme={colorScheme === 'dark' ? DarkTheme : DefaultTheme}>
        <StackNavigator />
      </NavigationContainer>
    </UserProvider>
  );
}
