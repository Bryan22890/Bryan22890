<?php
//Código PHP para o painel de acessibilidade
$menuVisible = false;
$fonteGrande = false;
$fundoEscuro = false;
$utterance = null;  //Variável para armazenar a utterance de leitura

//Função para mostrar/ocultar o painel de acessibilidade
function toggleAcessMenu() {
    global $menuVisible;
    $menuVisible = !$menuVisible;
    // Em PHP, não há manipulação direta do DOM; portanto, simulamos a alteração do estilo do painel
    // utilizando uma saída que define o estilo CSS para o elemento com id "painel-acessibilidade".
    $display = $menuVisible ? 'block' : 'none';
    echo "<style>#painel-acessibilidade { display: $display; }</style>";
}
?>


<?php
// Nenhuma dependência externa é necessária para este exemplo.
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Aumentar e Diminuir a Fonte</title>
    <style>
        .conteudo {
            /* Define um tamanho de fonte inicial */
            font-size: 16px;
            height: auto;
        }
    </style>
</head>
<body>
    <!-- Botão para aumentar a fonte -->
    <button id="increaseFont">Aumentar Fonte</button>

    <!-- Elemento que contém o conteúdo cujo tamanho de fonte será alterado -->
    <div class="conteudo">
        Lorem ipsum dolor sit amet, consectetur adipiscing elit.
    </div>

    <script>
    //Para aumentar e diminuir a fonte
    document.getElementById('increaseFont').addEventListener('click', function() {
      //Seleciona o elemento que contém o conteúdo cujo tamanho de fonte será alterado
      var content = document.querySelector('.conteudo');
        
      //Obtém o tamanho atual da fonte em pixels
      var currentFontSize = window.getComputedStyle(content, null).getPropertyValue('font-size');
      currentFontSize = parseInt(currentFontSize); //Converte o valor para inteiro

      // Define o tamanho máximo permitido (em px)
      var maxFontSize = 34;
      
      // Verifica se o tamanho atual é menor que o máximo permitido
      if (currentFontSize < maxFontSize) {
        // Aumenta o tamanho da fonte em 2px
        content.style.fontSize = (currentFontSize + 2) + 'px';
        // Ajusta o tamanho da caixa
        content.style.height = content.scrollHeight + 'px';
      }
    });
    </script>
</body>
</html>


<?php
// No additional PHP logic is required as this script outputs an HTML document containing the JavaScript functionality.
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Decrease Font Size</title>
    <style>
        .conteudo {
            font-size: 16px;
            height: auto;
        }
    </style>
</head>
<body>
    <!-- Button to trigger the font size decrease -->
    <button id="decreaseFont">Decrease Font Size</button>
    
    <!-- Element containing the content whose font size will be altered -->
    <div class="conteudo">
        <p>Sample content text.</p>
    </div>
    
    <script>
document.getElementById('decreaseFont').addEventListener('click', function() {
  //Seleciona o elemento que contém o conteúdo cujo tamanho de fonte será alterado
  var content = document.querySelector('.conteudo');
    
  //Obtém o tamanho atual da fonte em pixels
  var currentFontSize = window.getComputedStyle(content, null).getPropertyValue('font-size');
  currentFontSize = parseInt(currentFontSize); //Converte o valor para inteiro

  // Define o tamanho mínimo permitido (em px)
  var minFontSize = 10;
  
  // Verifica se o tamanho atual é maior que o mínimo permitido
  if (currentFontSize > minFontSize) {
    // Diminui o tamanho da fonte em 2px
    content.style.fontSize = (currentFontSize - 2) + 'px';
    // Ajusta o tamanho da caixa
    content.style.height = content.scrollHeight + 'px';
  }
});
    </script>
</body>
</html>



<?php
$pararLeitura = new Func("pararLeitura", function() use (&$utterance, &$window) {
  if (is($utterance)) {
    call_method(get($window, "speechSynthesis"), "cancel");
  }
});
$enviarFeedbackAceb = new Func("enviarFeedbackAceb", function() use (&$document, &$alert) {
  $feedback = get(call_method($document, "getElementById", "feedback"), "value");
  if (is($feedback)) {
    call($alert, "Obrigado pelo seu feedback!");
    set(call_method($document, "getElementById", "feedback"), "value", "");
  } else {
    call($alert, "Por favor, deixe seu feedback antes de enviar.");
  }

});
?>

<?php
$toggleFeedbackMenu = new Func("toggleFeedbackMenu", function() use (&$feedbackMenuVisible, &$document) {
  $feedbackMenuVisible = not($feedbackMenuVisible);
  $painel = call_method($document, "getElementById", "painel-feedback");
  set(get($painel, "style"), "display", is($feedbackMenuVisible) ? "block" : "none");
});
$enviarFeedback = new Func("enviarFeedback", function() use (&$document, &$alert) {
  $feedback = get(call_method($document, "getElementById", "feedback-text"), "value");
  if (is($feedback)) {
    call($alert, "Obrigado pelo seu feedback!");
    set(call_method($document, "getElementById", "feedback-text"), "value", "");
  } else {
    call($alert, "Por favor, digite um feedback antes de enviar.");
  }

});

?>


