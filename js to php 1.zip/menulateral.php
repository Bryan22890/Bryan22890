<?php
// Inicia a sessão para acessar a informação do usuário logado
session_start();
// Recupera o usuário logado da sessão (equivalente à recuperação do localStorage no JavaScript)
$usuarioLogado = isset($_SESSION['usuarioLogado']) ? $_SESSION['usuarioLogado'] : null;
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Usuário Logado</title>
        <script>
            //Recupera o usuário logado da sessão (traduzido do localStorage)
            document.addEventListener('DOMContentLoaded', () => {
<?php
// Verifica se o usuário logado existe na sessão e, se existir, insere o código JavaScript correspondente
if ($usuarioLogado) {
    // A conversão de PHP para JavaScript é feita usando json_encode para preservar a formatação da string
    echo "        //Verifica se o usuário logado existe\n";
    echo "        //Seleciona o elemento onde quer exibir o nome\n";
    echo "        const nomenatela = document.getElementById('nomenatela');\n";
    echo "        nomenatela.innerText = " . json_encode($usuarioLogado['login']) . ";\n";
    echo "        document.getElementById('user-info').style.display = 'block';\n";
}
?>
            });

            //Função para alternar o menu
            function toggleMenu() {
                const dropdown = document.getElementById('dropdown');
                dropdown.style.display = dropdown.style.display === 'none' ? 'block' : 'none';
            }
        </script>
    </head>
    <body>
        <div id="user-info" style="display: <?php echo $usuarioLogado ? 'block' : 'none'; ?>">
            <span id="nomenatela"></span>
        </div>
        <div id="dropdown" style="display: none;">
            <!-- Conteúdo do menu -->
        </div>
        <button onclick="toggleMenu()">Toggle Menu</button>
    </body>
</html>


<?php
// Inicia a sessão para armazenar os dados do usuário
session_start();

//A função de logout agora remove o item usuarioLogado corretamente
function logout() {
    // Remove o usuário logado da sessão, se existir
    if (isset($_SESSION['usuarioLogado'])) {
        unset($_SESSION['usuarioLogado']);
    }
    // Redireciona para a página inicial
    header("Location: ../html/telainicial.html");
    exit;
}



//A função authenticateUser agora cria um objeto de usuário antes de armazená-lo, para manter a estrutura do seu código.
//Função para autenticar o usuário
function authenticateUser($username) {
    //Cria um objeto de usuário
    $userObject = array("login" => $username);
    //Armazena no localStorage via sessão, convertendo para JSON
    $_SESSION['usuarioLogado'] = json_encode($userObject);
    //Redirecione ou atualize a interface conforme necessário
}
?>

