<?php
function generate_uuidv4() {
    return preg_replace_callback('/[xy]/', function($matches) {
        $uuid = random_int(0, 15);
        $v = $matches[0] === 'x' ? $uuid : ($uuid & 0x3 | 0x8);
        return dechex($uuid);
    }, 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx');
}

function SalvarDados() {
    $usuario = $_POST['campousuario'];
    $senha = $_POST['camposenha'];
    $email = $_POST['inserirEmail'];

    $usuarios = json_decode(file_get_contents('usuarios.json'), true) ?: [];
}
?> <?php
function generate_uuidv4() {
    // Implementação da função para gerar UUID v4
    return sprintf('%s-%s-%s-%s-%s',
        bin2hex(random_bytes(4)),
        bin2hex(random_bytes(2)),
        bin2hex(random_bytes(2)),
        bin2hex(random_bytes(2)),
        bin2hex(random_bytes(6))
    );
}

$novoUsuario = [
    'id' => generate_uuidv4(), // Chama a função para gerar UUID
    'login' => $usuario,
    'senha' => $senha,
    'email' => $email
];

// Aqui a gente pega a variável (usuarios) e adiciona o novo usuário (objeto) ao array
$usuarios[] = $novoUsuario;

// Depois que puxamos os novos dados, a gente usa o file_put_contents para salvar os novos dados no array, dentro do localstorage
file_put_contents('usuarios.json', json_encode($usuarios));
?> <?php
// Aqui, aparece uma mensagem no console
error_log(print_r($usuarios, true));
error_log('Dados salvos');

echo '<script>alert("Cadastro realizado com sucesso!");</script>';

// Validando todos os campos para serem preenchidos
function validarcadastro($event) {
    // Impede que o formulário seja enviado, caso esteja fora do padrão
    // O equivalente em PHP seria verificar se o formulário foi enviado e validar os campos
    $nomecompleto = $_POST['nomecompleto'];
    $datanascimento = $_POST['datanascimento'];
    // Continue com a validação dos campos...
}
?> <?php
$datanascimento = $_POST['datanascimento'];
$genero = $_POST['genero'];
$usuario = $_POST['campousuario'];
$senha = $_POST['camposenha'];
$confirmasenha = $_POST['confirmasenha'];
$cep = $_POST['cep'];
$num = $_POST['num'];
$tel = $_POST['tel'];
$cpf = $_POST['cpf'];
$Inseriremail = $_POST['inserirEmail'];

// Impedindo que o formulário seja enviado com campos em branco
if ($nomecompleto === '' || $datanascimento === '' || $genero === '' || $senha === '' || $confirmasenha === '' || $usuario === '' || $cep === '' || $num === '' || $tel === '' || $cpf === '' || $Inseriremail === '') {
    echo '<script>alert("[ERRO] Os campos são obrigatórios, por favor não deixe de preencher.");</script>';
    return false;
}
?> <?php
// Incluindo dependências necessárias
// Não há dependências externas requeridas para esta implementação

// Para simulação, assumimos que os dados são enviados via método POST
$senha = $_POST['senha'] ?? '';
$confirmasenha = $_POST['confirmasenha'] ?? '';
$cpf = $_POST['cpf'] ?? '';

//Validando se as duas senhas estão iguais
if ($senha !== $confirmasenha){
    echo "<script>alert('[ERRO] As senhas não coincidem.');</script>";
    return false;
}

//Não deixa passar a validação do CPF
if (!validarCPF($cpf)) {
    return false;
}

//aqui a gente chama a função acima, mas só se os dados forem devidamente validados.
SalvarDados();

header("Location: ../html/telalogin.html");
exit();

//Formato XXXXX-XXX do CEP
function formatarCEP($input) {
    $cep = preg_replace('/\D/', '', $input->value); //Remove caracteres não numéricos

    if (strlen($cep) > 8) { //Verifica se o CEP tem 8 dígitos
        $cep = substr($cep, 0, 8);
    }
    if (strlen($cep) > 5) { //Adiciona o hífen
        $cep = substr($cep, 0, 5) . '-' . substr($cep, 5); //'.slice' é usado para extrair uma parte de uma string ou de um array e retorná-la como uma nova string
    }
    $input->value = $cep;
}

// Implementação para validarCPF
function validarCPF($cpf) {
    // Remove qualquer caractere não numérico
    $cpf = preg_replace('/\D/', '', $cpf);
    
    // Verifica se o CPF possui 11 dígitos
    if (strlen($cpf) != 11) {
        echo "<script>alert('[ERRO] CPF inválido.');</script>";
        return false;
    }
    
    // Verifica se todos os dígitos são iguais
    if (preg_match('/^(\\d)\\1{10}$/', $cpf)) {
        echo "<script>alert('[ERRO] CPF inválido.');</script>";
        return false;
    }
    
    // Validação do primeiro dígito verificador
    $sum = 0;
    for ($i = 0; $i < 9; $i++) {
        $sum += intval($cpf[$i]) * (10 - $i);
    }
    $firstCheck = 11 - ($sum % 11);
    if ($firstCheck >= 10) {
        $firstCheck = 0;
    }
    if (intval($cpf[9]) !== $firstCheck) {
        echo "<script>alert('[ERRO] CPF inválido.');</script>";
        return false;
    }
    
    // Validação do segundo dígito verificador
    $sum = 0;
    for ($i = 0; $i < 10; $i++) {
        $sum += intval($cpf[$i]) * (11 - $i);
    }
    $secondCheck = 11 - ($sum % 11);
    if ($secondCheck >= 10) {
        $secondCheck = 0;
    }
    if (intval($cpf[10]) !== $secondCheck) {
        echo "<script>alert('[ERRO] CPF inválido.');</script>";
        return false;
    }
    return true;
}

// Implementação para SalvarDados (salvando os dados)
function SalvarDados() {
    // Implementação dummy para salvar os dados
    // Em um cenário real, esta função salvava os dados em um banco de dados ou realizava outras ações necessárias.
    echo "<script>alert('Dados salvos com sucesso.');</script>";
}

// Classe de suporte para representar o elemento 'input' utilizado na função formatarCEP
class Input {
    public $value;
    public function __construct($value = '') {
        $this->value = $value;
    }
}
?> <?php
// No additional dependencies are required since we are using PHP's built-in cURL functions and default libraries.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['buscar'])) {
    // First event listener equivalent: Fetch address data using the provided CEP.
    $cep = isset($_POST['cep']) ? $_POST['cep'] : '';

    // Initialize cURL to fetch data from the API.
    $ch = curl_init();
    $url = "https://viacep.com.br/ws/" . urlencode($cep) . "/json/";
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);

    if ($response === false) {
        // Error handling: If the cURL request fails, alert an error and log the error.
        $alertMessage = "Erro ao buscar o CEP.";
        error_log("Erro: " . curl_error($ch));
        curl_close($ch);
        $data = null;
    } else {
        $data = json_decode($response, true);
        curl_close($ch);
    }
    
    if ($data && isset($data['erro']) && $data['erro']) {
        // If an error is returned from the API, alert that the CEP was not found.
        $alertMessage = "CEP não encontrado.";
        $logradouro = "";
        $bairro = "";
        $cidade = "";
    } elseif ($data) {
        $logradouro = isset($data['logradouro']) ? $data['logradouro'] : "";
        $bairro = isset($data['bairro']) ? $data['bairro'] : "";
        $cidade = isset($data['localidade']) ? $data['localidade'] : "";
        $alertMessage = "";
    } else {
        $logradouro = "";
        $bairro = "";
        $cidade = "";
        if (!isset($alertMessage)) {
            $alertMessage = "Erro ao buscar o CEP.";
        }
    }
    
    // Second event listener equivalent:
    // Clear the content of the address fields after performing the fetch.
    // This exactly emulates the second event listener in the original JavaScript.
    $logradouro = "";
    $bairro = "";
    $cidade = "";
} else {
    $cep = "";
    $logradouro = "";
    $bairro = "";
    $cidade = "";
    $alertMessage = "";
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Buscar CEP</title>
</head>
<body>
    <?php
    // If there is an alert message, display it via JavaScript alert.
    if (!empty($alertMessage)) {
        echo "<script>alert('{$alertMessage}');</script>";
    }
    ?>
    <!-- The form below simulates the HTML elements referenced in the JavaScript code,
         including inputs for CEP, rua (logradouro), bairro, and cidade.
         The 'Buscar' button is used to trigger the PHP code that performs the API call. -->
    <form method="POST" action="">
        <!-- Input for CEP -->
        <label for="cep">CEP:</label>
        <input type="text" id="cep" name="cep" value="<?php echo htmlspecialchars($cep); ?>">
        <br><br>
        <!-- Input for Rua (logradouro) -->
        <label for="rua">Rua:</label>
        <input type="text" id="rua" name="rua" value="<?php echo htmlspecialchars($logradouro); ?>">
        <br><br>
        <!-- Input for Bairro -->
        <label for="bairro">Bairro:</label>
        <input type="text" id="bairro" name="bairro" value="<?php echo htmlspecialchars($bairro); ?>">
        <br><br>
        <!-- Input for Cidade (localidade) -->
        <label for="cidade">Cidade:</label>
        <input type="text" id="cidade" name="cidade" value="<?php echo htmlspecialchars($cidade); ?>">
        <br><br>
        <button type="submit" id="buscar" name="buscar">Buscar</button>
    </form>
</body>
</html> <?php
//Formato (XX) XXXXX-XXXX do TELEFONE
function formatarTEL($input){
    $tel = preg_replace('/\D/', '', $input->value); //Remove caracteres não numéricos

    if (strlen($tel) > 11) { //Verifica se o TEL tem 11 dígitos
        $tel = substr($tel, 0, 11);
    }
    if (strlen($tel) === 11) { //Adiciona os parenteses e o hífen
        $tel = "(" . substr($tel, 0, 2) . ") " . substr($tel, 2, 5) . "-" . substr($tel, 7);
    } else if (strlen($tel) === 10) {
        $tele = $tel;
        $tel = "(" . substr($tel, 0, 2) . ") " . substr($tele, 2, 4) . "-" . substr($tele, 6);
    }
    $input->value = $tel;
}

//Validando o CPF com o digito verificador
function validarCPF($cpf) {
    /*O código implementa o algorito de validação de CPF definido pela Receita Federal
    O calculo do primeiro dígito verificar(dv1):
    -Multiplica os primeiros 9 dígitos do CPF por pesos decrescente de 10 a 2;
    -Calcula o resto da divisão da soma pelo número 11;
    -Se o resto for 10 ou 11, o dv1 é 0; caso contrário, é o próprio resto.
    O calculo do segundo dígito verificador(dv2):
    -Multiplica os primeiros 9 dígitos do CPF por pesos decrescente de 11 a 2, incluindo o dv1;
    -Calcula o resto da divisão da soma pelo número 11;
    -Se o resto for 10 ou 11, o dv2 é 0; caso contrário, é o próprio resto.
    O código verifica se os 2 dígitos verificadores calculados correspondem aos 2 últimos dígitos do CPF informado, Se correspondem, o CPF é considerado válido.*/
}
?> <?php
// No external dependencies are required for this PHP implementation

function validateCPF($cpf) {
    $soma = 0;
    $soma += $cpf[0] * 10;
    $soma += $cpf[1] * 9;
    $soma += $cpf[2] * 8;
    $soma += $cpf[3] * 7;
    $soma += $cpf[4] * 6;
    $soma += $cpf[5] * 5;
    $soma += $cpf[6] * 4;
    $soma += $cpf[7] * 3;
    $soma += $cpf[8] * 2;
    $soma = ($soma * 10) % 11;
    if ($soma == 10 || $soma == 11) $soma = 0;
    if ($soma != $cpf[9]) {
        echo "<script>alert('[ERRO] CPF inválido!');</script>";
        return false;
    }

    $soma = 0;
    $soma += $cpf[0] * 11;
    $soma += $cpf[1] * 10;
    $soma += $cpf[2] * 9;
    $soma += $cpf[3] * 8;
    $soma += $cpf[4] * 7;
    $soma += $cpf[5] * 6;
    $soma += $cpf[6] * 5;
    $soma += $cpf[7] * 4;
    $soma += $cpf[8] * 3;
    $soma += $cpf[9] * 2;
    $soma = ($soma * 10) % 11;
    if ($soma == 10 || $soma == 11) $soma = 0;
    if ($soma != $cpf[10]) {
        echo "<script>alert('[ERRO] CPF inválido!');</script>";
        return false;
    }
    return true;
}
?>
<?php
//Formato exemplo@email.com do E-mail
function validarEmail($input) {
    $re = '/^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$/';
    return preg_match($re, $input) === 1;
/*expressão regular  
- ^ : início da string
- [a-zA-Z0-9._%+\-]+ : caracteres permitidos antes do @ (letras, números, ., _, %, +, -)
- @ : símbolo @
- [a-zA-Z0-9.\-]+ : caracteres permitidos após o @ (letras, números, ., -)
- \. : ponto antes da extensão
- [a-zA-Z]{2,} : extensão do domínio (letras, mínimo 2 caracteres)
- $ : fim da string*/
}

//Restrição de idade
function validarIdade($dataNascimento) {
    $data = new DateTime($dataNascimento); //A data de nascimento é convertida para um objeto
    $dataAtual = new DateTime(); //Uma nova instância de Date é criada para obter a data atual
    $anoAtual = (int)$dataAtual->format('Y'); //O ano atual é extraído da data atual usando o método 'format('Y')'
    $anoNascimento = (int)$data->format('Y');
    
    $idade = $anoAtual - $anoNascimento; //A idade é calculada subtraindo o ano de nascimento do ano atual.
    
    if ($idade < 12) {
      echo "<script>alert('Você deve ter pelo menos 10 anos para continuar.');</script>";
      echo "<script>document.getElementById('datanascimento').value = '';</script>"; // Limpa o campo
      return false;
    } else {
      return true;
    }
}
?></br>
