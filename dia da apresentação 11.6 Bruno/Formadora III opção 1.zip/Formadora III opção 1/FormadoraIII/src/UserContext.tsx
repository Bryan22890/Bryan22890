import React, { createContext, useState, ReactNode } from 'react';

type User = { id: string; nome: string; email: string };

type UserContextType = {
  loggedIn: boolean;
  users: User[];
  login: () => void;
  logout: () => void;
  addUser: (user: User) => void;
};

export const UserContext = createContext<UserContextType>({
  loggedIn: false,
  users: [],
  login: () => {},
  logout: () => {},
  addUser: () => {},
});

export const UserProvider = ({ children }: { children: ReactNode }) => {
  const [loggedIn, setLoggedIn] = useState(false);
  const [users, setUsers] = useState<User[]>([]);

  const login = () => setLoggedIn(true);
  const logout = () => setLoggedIn(false);

  const addUser = (user: User) => setUsers((prev) => [...prev, user]);

  return (
    <UserContext.Provider value={{ loggedIn, users, login, logout, addUser }}>
      {children}
    </UserContext.Provider>
  );
};
