export const colors = {
  // Suporte a tema claro e escuro
  primary: '#4CAF50',
  secondary: '#1E88E5',

  backgroundLight: '#F5F5F5',
  backgroundDark: '#121212',

  textPrimary: '#FFFFFF',
  textSecondary: '#B0B0B0',

  border: '#333333',
  inputBackground: '#1E1E1E',
};
