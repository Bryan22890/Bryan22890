import React, { useContext } from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';
import { UserContext } from '../UserContext';

export default function ListaUsuariosScreen() {
  const { users } = useContext(UserContext);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Usuários Cadastrados</Text>
      <FlatList
        data={users}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.name}>{item.nome}</Text>
            <Text style={styles.email}>{item.email}</Text>
          </View>
        )}
        ListEmptyComponent={<Text style={styles.empty}>Nenhum usuário cadastrado.</Text>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  title: { fontSize: 20, fontWeight: '700', marginBottom: 12, textAlign: 'center' },
  card: { padding: 12, backgroundColor: '#f8f8f8', borderRadius: 8, marginBottom: 8 },
  name: { fontWeight: '700' },
  email: { color: '#666', marginTop: 4 },
  empty: { color: '#777', textAlign: 'center', marginTop: 20 },
});
