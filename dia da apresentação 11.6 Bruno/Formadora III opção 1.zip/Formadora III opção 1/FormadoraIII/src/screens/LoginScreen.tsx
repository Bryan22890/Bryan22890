import React, { useContext, useState } from 'react';
import { View, Text, StyleSheet, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import CustomInput from '../components/CustomInput';
import CustomButton from '../components/CustomButton';
import { UserContext } from '../UserContext';


export default function LoginScreen({ navigation }: any) {
const [email, setEmail] = useState('');
const [senha, setSenha] = useState('');
const { login } = useContext(UserContext);


const handleLogin = () => {
if (!email || !senha) return Alert.alert('Erro', 'Preencha email e senha.');


const ok = login(email.trim().toLowerCase(), senha);
if (ok) {
navigation.reset({ index: 0, routes: [{ name: 'ListaUsuarios' }] });
} else {
Alert.alert('Erro', 'Email ou senha inválidos.');
}
};


return (
<KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.container}>
<View style={styles.card}>
<Text style={styles.title}>Bem-vindo(a) de volta!</Text>


<CustomInput placeholder="Email" value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" />
<CustomInput placeholder="Senha" value={senha} onChangeText={setSenha} secureTextEntry />


<CustomButton title="Entrar" onPress={handleLogin} />


<Text style={styles.link} onPress={() => navigation.navigate('Cadastro')}>Não tem uma conta? Cadastre-se</Text>
</View>
</KeyboardAvoidingView>
);
}


const styles = StyleSheet.create({
container: { flex: 1, justifyContent: 'center', backgroundColor: '#f2f4f8' },
card: { margin: 20, padding: 20, backgroundColor: '#fff', borderRadius: 12, elevation: 3 },
title: { fontSize: 22, fontWeight: '700', marginBottom: 12, textAlign: 'center' },
link: { color: '#2b6ef6', marginTop: 12, textAlign: 'center' }
});