<?php
$startGameButton = '<button class="start-quiz">Start Quiz</button>';
$questionsContainer = '<div class="questions-container"></div>';
$answersContainer = '<div class="answers-container"></div>';
$questionText = '<div class="question"></div>';
$nextQuestionButton = '<button class="next-question">Next Question</button>';

echo $startGameButton;
echo $questionsContainer;
echo $answersContainer;
echo $questionText;
echo $nextQuestionButton;

echo '<script>
    document.querySelector(".start-quiz").addEventListener("click", startGame);
    document.querySelector(".next-question").addEventListener("click", displayNextQuestion);
    
    let currentQuestionIndex = 0;
    let totalCorrect = 0;
</script>';
?>


<?php
session_start();

function startGame() {
    // Faz com que o botão desapareça adicionando a classe 'hide'
    echo "<script>document.getElementById('startGameButton').classList.add('hide');</script>";

    // Faz com que o container de perguntas apareça removendo a classe 'hide'
    echo "<script>document.getElementById('questionsContainer').classList.remove('hide');</script>";

    // Depois, a função displayNextQuestion() é chamada
    displayNextQuestion();
}

function displayNextQuestion() {
    resetState(); // Chama a função que reseta o estado das perguntas

    // Verifica se todas as perguntas já foram mostradas
    if (count($_SESSION['questions']) === $_SESSION['currentQuestionIndex']) {
        // Se o número de questões for igual ao índice atual, o jogo termina
        return finishGame();
    }

    // Aqui você carregaria a próxima pergunta (exemplo genérico)
    $question = $_SESSION['questions'][$_SESSION['currentQuestionIndex']];
    echo "<div class='question'>{$question}</div>";

    // Incrementa o índice para a próxima pergunta
    $_SESSION['currentQuestionIndex']++;
}

function resetState() {
    // Aqui você pode limpar as respostas ou esconder perguntas anteriores
    echo "<script>
        const answerButtons = document.querySelectorAll('.btn');
        answerButtons.forEach(btn => btn.classList.add('hide'));
    </script>";
}

function finishGame() {
    echo "<div>Jogo finalizado! Obrigado por jogar.</div>";
}
?>

<?php
function showQuestion($questions, $currentQuestionIndex) {
    $currentQuestion = $questions[$currentQuestionIndex];

    // Mostra o texto da pergunta
    echo "<div id='questionText'>{$currentQuestion['question']}</div>";

    // Mostra as respostas
    echo "<div id='answersContainer'>";
    foreach ($currentQuestion['answers'] as $answer) {
        // Define se a resposta está correta
        $dataCorrect = $answer['correct'] ? 'true' : 'false';

        // Cria o botão com atributos e eventos
        echo "<button class='button answer' data-correct='{$dataCorrect}'>
                {$answer['text']}
              </button>";
    }
    echo "</div>";

    // Adiciona o ouvidor de eventos via JavaScript
    echo "<script>
        document.querySelectorAll('.answer').forEach(button => {
            button.addEventListener('click', selectAnswer);
        });

        function selectAnswer(e) {
            const selected = e.target;
            const isCorrect = selected.dataset.correct === 'true';

            if (isCorrect) {
                alert('Correto!');
            } else {
                alert('Errado!');
            }

            // Aqui você pode redirecionar ou carregar a próxima pergunta via AJAX ou reload
        }
    </script>";
}
?>

    
<?php
function resetState() {
    echo "<script>
        // Enquanto houver elementos filhos no container de respostas, eles serão removidos
        const answersContainer = document.getElementById('answersContainer');
        while (answersContainer.firstChild) {
            answersContainer.removeChild(answersContainer.firstChild);
        }

        // Remove classes do <body>, como a cor de fundo que indica acerto/erro
        document.body.removeAttribute('class');

        // Esconde o botão de 'Próxima pergunta'
        const nextQuestionButton = document.getElementById('nextQuestionButton');
        nextQuestionButton.classList.add('hide');
    </script>";
}
?>

<?php
function addSelectAnswerScript() {
    echo "<script>
        let totalCorrect = 0;
        let currentQuestionIndex = 0;

        function selectAnswer(event) {
            const answerClicked = event.target;

            // Verifica se a resposta clicada está correta
            if (answerClicked.dataset.correct === 'true') {
                // document.body.classList.add('correct'); // opcional
                totalCorrect++;
            } else {
                // document.body.classList.add('incorrect'); // opcional
            }

            // Mostra visualmente quais botões estão certos ou errados
            document.querySelectorAll('.answer').forEach(button => {
                if (button.dataset.correct === 'true') {
                    button.classList.add('correct');
                } else {
                    button.classList.add('incorrect');
                }
                button.disabled = true; // Evita múltiplos cliques
            });

            // Mostra o botão 'Próxima Pergunta'
            document.getElementById('nextQuestionButton').classList.remove('hide');

            // Avança para a próxima pergunta (lógica adicional pode ser necessária)
            currentQuestionIndex++;
        }
    </script>";
}
?>

<?php
addSelectAnswerScript();
?>

<?php
function finishGameScript() {
    echo "<script>
        function finishGame() {
            const totalQuestion = questions.length;
            const performance = Math.floor(totalCorrect * 100 / totalQuestion);
            let message = '';

            switch (true) {
                case (performance < 33):
                    message = 'Iniciante: você está começando a explorar o mundo da reciclagem! Sabia que reciclagem foi assunto no Enem? É um assunto importante e você vai descobrir coisas incríveis no Eco Point! Cadastre-se ou entre com sua conta em nosso site para saber mais.';
                    break;
                case (performance < 67):
                    message = 'Intermediário: você está fazendo um ótimo trabalho, mas que tal aumentar o seu repertório sobre reciclagem eletrônica? Você vai aprender coisas novas e interessantes! Cadastre-se ou entre com sua conta em nosso site para saber mais.';
                    break;
                case (performance >= 67):
                    message = 'Especialista: você é um verdadeiro especialista em reciclagem eletrônica! Que tal saber mais sobre como descartar os resíduos eletrônicos corretamente? Você vai aprender coisas incríveis e poderá ajudar a proteger o meio ambiente! Cadastre-se ou entre com sua conta em nosso site para saber mais.';
                    break;
                default:
                    message = 'Erro';
                    break;
            }

            document.getElementById('questionsContainer').innerHTML = 
                '<p class=\"final-message\">Você acertou ' + totalCorrect + 
                ' de ' + totalQuestion + 
                ' questões! <br> <span>' + message + 
                '</span></p><button class=\"button\" onclick=\"window.location.reload()\"> Refazer teste </button>';
        }
    </script>";
}
?>

<?php
$questions = [
    [
        'question' => 'Qual é o principal objetivo da reciclagem eletrônica?',
        'answers' => [
            ['text' => 'Reduzir custos de produção', 'correct' => false],
            ['text' => 'Conservar recursos naturais e reduzir resíduos', 'correct' => true],
            ['text' => 'Aumentar a vida útil dos produtos', 'correct' => false],
            ['text' => 'Reduzir a dependência de recursos não renováveis', 'correct' => false],
        ]
    ],
    [
        'question' => 'Qual é o nome da diretiva da União Europeia que regula a reciclagem de equipamentos elétricos e eletrônicos?',
        'answers' => [
            ['text' => 'WEEE', 'correct' => true],
            ['text' => 'RoHS', 'correct' => false],
            ['text' => 'REACH', 'correct' => false],
            ['text' => 'EEE', 'correct' => false],
        ]
    ],
    [
        'question' => 'Quais são os principais componentes tóxicos encontrados em equipamentos eletrônicos?',
        'answers' => [
            ['text' => 'Plástico, vidro e madeira', 'correct' => false],
            ['text' => 'Cobre, alumínio e ferro', 'correct' => false],
            ['text' => 'Chumbo, mercúrio e cádmio', 'correct' => true],
            ['text' => 'Estanho, prata e ouro', 'correct' => false],
        ]
    ],
];
?>

<?php
$questions = [
    [
        'question' => 'Qual é o principal objetivo da reciclagem eletrônica?',
        'answers' => [
            ['text' => 'Reduzir custos de produção', 'correct' => false],
            ['text' => 'Conservar recursos naturais e reduzir resíduos', 'correct' => true],
            ['text' => 'Aumentar a vida útil dos produtos', 'correct' => false],
            ['text' => 'Reduzir a dependência de recursos não renováveis', 'correct' => false]
        ]
    ],
    [
        'question' => 'Qual é o nome da diretiva da União Europeia que regula a reciclagem de equipamentos elétricos e eletrônicos?',
        'answers' => [
            ['text' => 'WEEE', 'correct' => true],
            ['text' => 'RoHS', 'correct' => false],
            ['text' => 'REACH', 'correct' => false],
            ['text' => 'EEE', 'correct' => false]
        ]
    ],
    [
        'question' => 'Quais são os principais componentes tóxicos encontrados em equipamentos eletrônicos?',
        'answers' => [
            ['text' => 'Plástico, vidro e madeira', 'correct' => false],
            ['text' => 'Cobre, alumínio e ferro', 'correct' => false],
            ['text' => 'Chumbo, mercúrio e cádmio', 'correct' => true],
            ['text' => 'Estanho, prata e ouro', 'correct' => false]
        ]
    ],
    [
        'question' => 'Qual é o processo de reciclagem que envolve a separação de materiais por densidade?',
        'answers' => [
            ['text' => 'Triagem', 'correct' => true],
            ['text' => 'Fragmentação', 'correct' => false],
            ['text' => 'Flutuação', 'correct' => false],
            ['text' => 'Classificação por tamanho', 'correct' => false]
        ]
    ],
    [
        'question' => 'Qual é o tipo de resíduo eletrônico mais comum?',
        'answers' => [
            ['text' => 'Monitores', 'correct' => false],
            ['text' => 'Computadores', 'correct' => false],
            ['text' => 'Televisores', 'correct' => false],
            ['text' => 'Telefones celulares', 'correct' => true]
        ]
    ],
    [
        'question' => 'Qual é o país com a maior quantidade de resíduos eletrônicos no mundo?',
        'answers' => [
            ['text' => 'Índia', 'correct' => false],
            ['text' => 'Estados Unidos', 'correct' => false],
            ['text' => 'China', 'correct' => true],
            ['text' => 'Japão', 'correct' => false]
        ]
    ],
    [
        'question' => 'Qual é o termo técnico para a reciclagem de materiais eletrônicos por meio da aplicação de calor e pressão?',
        'answers' => [
            ['text' => 'Pirometálurgia', 'correct' => true],
            ['text' => 'Hidrometálurgia', 'correct' => false],
            ['text' => 'Eletrometálurgia', 'correct' => false],
            ['text' => 'Siderurgia', 'correct' => false]
        ]
    ],
    [
        'question' => 'Qual é o nome do protocolo internacional que visa reduzir a produção de resíduos eletrônicos?',
        'answers' => [
            ['text' => 'Acordo de Paris', 'correct' => false],
            ['text' => 'Convenção de Estocolmo', 'correct' => false],
            ['text' => 'Protocolo de Basileia', 'correct' => true],
            ['text' => 'Convenção de Genebra', 'correct' => false]
        ]
    ],
    [
        'question' => 'Qual é o processo mais comum utilizado para reciclar metais pesados em equipamentos eletrônicos?',
        'answers' => [
            ['text' => 'Fusão', 'correct' => false],
            ['text' => 'Eletrolise', 'correct' => false],
            ['text' => 'Separação magnética', 'correct' => true],
            ['text' => 'Extração química', 'correct' => false]
        ]
    ],
    [
        'question' => 'Quais são os dois países que mais reciclam lixo eletrônico?',
        'answers' => [
            ['text' => 'Islândia e Suécia', 'correct' => true],
            ['text' => 'China e EUA', 'correct' => false],
            ['text' => 'Brasil e Japão', 'correct' => false],
            ['text' => 'Canadá e Austrália', 'correct' => false]
        ]
    ],
    [
        'question' => 'Qual é o benefício da reciclagem eletrônica em relação à criação de empregos?',
        'answers' => [
            ['text' => 'Melhora a eficiência energética', 'correct' => false],
            ['text' => 'Reduz a necessidade de mão de obra', 'correct' => false],
            ['text' => 'Aumenta a automação', 'correct' => false],
            ['text' => 'Gera empregos em diversas áreas', 'correct' => true]
        ]
    ],
    [
        'question' => 'Qual é o impacto ambiental do descarte inadequado de pilhas e baterias?',
        'answers' => [
            ['text' => 'Contaminação do solo e da água', 'correct' => true],
            ['text' => 'Aquecimento global', 'correct' => false],
            ['text' => 'Perda de biodiversidade', 'correct' => false],
            ['text' => 'Alteração do ciclo de nutrientes', 'correct' => false]
        ]
    ]
];
?>

